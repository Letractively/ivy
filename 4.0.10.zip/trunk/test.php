<?php
/**
 * Loader file
 *
 * $Date: 2011-02-06 14:36:04 +0000 (Sun, 06 Feb 2011) $
 * $author: james.randell.user@googlemail.com $
 * 
 * $Revision: 10 $
 * 
 */
include_once 'ivy/core/controller/ivy.php';

$ivy = new ivy();
$ivy->loader();

?>