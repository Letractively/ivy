<?php

class application_controller {


public function __construct ()
{
	
}	
	
public function index ()
{
	echo 'This is the ivy site index method';
}

}
	
?>