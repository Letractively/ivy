<?php
class ivy_display {
	
public $a = 'This is a from ivy_display';

protected function index () {}

}